# gmaps-page-places
Show Wordpress pages on a Google maps view
