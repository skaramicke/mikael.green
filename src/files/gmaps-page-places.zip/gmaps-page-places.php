<?php

/**
 * Plugin Name: Google Maps Page Places
 */

// Enqueue public scripts
add_action('wp_enqueue_scripts', function () use ($assets) {
  if (is_page()) {
    require_once(dirname(__FILE__) . '/public/dist/assets.php');
    if (isset($assets) && count($assets)) {
      foreach ($assets as $name => $js) {
        wp_enqueue_script('gmaps-page-places-' . $name, plugins_url('/public/dist/' . $js, __FILE__), [], 'v1.0.2', 'in_footer');
      }
    }
  }
});

// Enqueue admin scripts
add_action('admin_enqueue_scripts', function () use ($assets) {
  if (is_admin()) {
    require_once(dirname(__FILE__) . '/admin/dist/assets.php');
    if (isset($assets) && count($assets)) {
      foreach ($assets as $name => $js) {
        wp_enqueue_script('gmaps-page-places-' . $name, plugins_url('/admin/dist/' . $js, __FILE__), [], 'v1.0.2', 'in_footer');
      }
    }
  }
});

// Output javascript in header for page specific markers
add_action('wp_head', function () use ($assets) {
  if (is_page()) {
    global $post;
    $markers_json = get_post_meta($post->ID, 'gmaps_page_places_markers', true);

    echo '
<script>
  var gmapsPagePlaces = '.$markers_json.';
</script>
';
  }
});

// Metabox for Google Maps Page Places
add_action('add_meta_boxes', function () {
  add_meta_box('gmaps-page-places', 'Google Maps Page Places', function ($post) {
    $markers_json = get_post_meta($post->ID, 'gmaps_page_places_markers', true);
?>
    <div id="gmaps-page-places-app-root" data-markers='<?php echo $markers_json; ?>' />
<?php
  }, 'page', 'normal', 'high');
});

// Save markers when edit page form is posted
add_action('save_post', function ($post_id) {
  if (isset($_POST['gmaps_page_places_markers'])) {
    $markerData = [];
    foreach ($_POST['gmaps_page_places_markers'] as $id => $marker) {
      if ($id) {
        $markerData[] = [
          'id' => sanitize_text_field($id),
          'position' => [
            'lat' => sanitize_text_field($marker['position']['lat']),
            'lng' => sanitize_text_field($marker['position']['lng']),
          ],
          'title' => sanitize_text_field($marker['title']),
          'label' => sanitize_text_field($marker['label']),
        ];
      }
    }

    $markerData = json_encode($markerData, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    update_post_meta($post_id, 'gmaps_page_places_markers', $markerData);
  }
});
